export default {
  base: '/',
}
